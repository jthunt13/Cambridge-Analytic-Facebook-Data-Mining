{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf400
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww17720\viewh11340\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 ################################################################################\
#  NewsData\
################################################################################\
\
Description: folder containing data acquired from the NYT api\
\
Contents:\
\
 1. \'93CambridgeAnalyticURL2018-04-04.csv\'94\
\
	-file containing the NYT article ID, article URL and article publication date for articles containing keywords \'93cambridge\'94 and \'93analytic\'94.\
 \
2. \'93FacebookURL2018-04-04.csv\'94\
\
	-file containing the NYT article ID, article URL and article publication date for articles containing keywords \'93cambridge\'94 and \'93analytic\'94.\
\
3. \'93cambridgeAnalytic/\'94\
\
	-folder containing .txt files of the content of each article, each file title is the article ID.\
\
4. \'93cambridgeAnalyticCo/\'94\
\
	-folder containing only the latest 50 articles from \'93NewsData/cambridgeAnalytic/\'93, used for the word co-occurence map reduce for a reasonable run time.\
\
5. \'93facebook/\'93\
\
	-folder containing .txt files of the content of each article, each file title is the article ID.\
\
6. \'93facebookCo/\'94\
\
	-folder containing only the latest 50 articles from \'93NewsData/cambridgeAnalytic/\'93, used for the word co-occurence map reduce for a reasonable run time.\
\
################################################################################\
#  NewsWords\
################################################################################\
\
Description: folder containing map reduce results for the NYT data\
\
Contents:\
\
1. \'93wordCountNYTCambridgeAnalytic.txt\'94\
\
	-file containing the word counts from every article in \'93NewsData/cambridgeAnalytic/\'94\
\
2. \'93wordCountNYTFacebook.txt\'94\
\
	-file containing the word counts from every article in \'93NewsData/facebook/\'94\
\
3. \'93cooccurNYTCambridgeAnalytic.txt\'94\
\
	-file containing the top 10 co-occuring words from every article in \'93NewsData/cambridgeAnalyticCo/\'94\
\
4. \'93cooccurNYTFacebook.txt\'94\
\
	-file containing the top 10 co-occuring words from every article in \'93NewsData/facebookCo/\'94\
\
################################################################################\
#  TwitterData\
################################################################################\
\
Description: folder containing data acquired from the NYT api\
\
Contents:\
\
1. \'93cambridgeAnalyticTweetID_CSV_2018-04-06\'94\
\
	-file containing the tweet ID and tweet date for tweets containing keyword \'93cambridge analytic\'94.\
\
2. \'93facebookTweetID_CSV_2018-04-06\'94\
\
	-file containing the tweet ID and tweet date for tweets containing keyword \'93facebook\'94.\
\
3. \'93cambridgeAnalytic/\'93\
\
	-folder housing tweets merged into a single .txt file\
\
3. \'93facebook/\'93\
\
	-folder housing tweets merged into multiple .txt files to reduce overhead\
\
################################################################################\
#  TwitterWords\
################################################################################\
Description: folder containing map reduce results for the NYT data\
\
Contents:\
\
1. \'93wordCountTwitterCambridgeAnalytic.txt\'94\
\
	-file containing the word counts from every tweet stored in \'93TwitterData/cambridgeAnalytic/\'94\
\
2. \'93wordCountNYTFacebook.txt\'94\
\
	-file containing the word counts from every tweet stored in \'93TwitterData/facebook/\'94\
\
3. \'93cooccurNYTCambridgeAnalytic.txt\'94\
\
	-file containing the top 10 co-occuring words from every tweet stored in \'93TwitterData/cambridgeAnalyticCo/\'94\
\
4. \'93cooccurNYTFacebook.txt\'94\
\
	-file containing the top 10 co-occuring words from every tweet stored in \'93TwitterData/facebookCo/\'94}